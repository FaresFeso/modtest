package com.bazaaralert.client.parser;

import com.bazaaralert.client.model.BazaarOrder;
import com.bazaaralert.client.model.OrderType;

import com.bazaaralert.client.util.TextUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public final class OrderInventoryParser {
	private static final Pattern ORDER_NAME = Pattern.compile("(?i)(BUY|SELL)\\s+(.*)");
	private static final Pattern PRICE_LINE = Pattern.compile("Price per unit: ([\\d,.]+) coins");
	private static final Pattern AMOUNT_LINE = Pattern.compile("Amount: ([\\d,]+)x");

	private OrderInventoryParser() {
	}

	public static boolean isOrdersInventory(String title) {
		return "Your Bazaar Orders".equals(title) || "Co-op Bazaar Orders".equals(title);
	}

	public static List<BazaarOrder> parse(class_465<?> screen) {
		List<BazaarOrder> orders = new ArrayList<>();

		for (class_1735 slot : screen.method_17577().field_7761) {
			class_1799 stack = slot.method_7677();
			if (stack.method_7960()) {
				continue;
			}

			parseStack(stack).ifPresent(orders::add);
		}

		return orders;
	}

	private static java.util.Optional<BazaarOrder> parseStack(class_1799 stack) {
		String displayName = TextUtils.stripColor(stack.method_7964().getString());
		Matcher nameMatcher = ORDER_NAME.matcher(displayName);
		if (!nameMatcher.matches()) {
			return java.util.Optional.empty();
		}

		OrderType type = "BUY".equalsIgnoreCase(nameMatcher.group(1)) ? OrderType.BUY : OrderType.SELL;
		String itemName = nameMatcher.group(2).trim();
		String productId = TextUtils.displayNameToProductId(itemName);


		double price = 0.0D;
		long amount = 0L;
		class_9290 lore = stack.method_58694(class_9334.field_49632);
		if (lore != null) {
			for (class_2561 line : lore.comp_2400()) {
				String text = TextUtils.stripColor(line.getString());
				Matcher priceMatcher = PRICE_LINE.matcher(text);
				if (priceMatcher.matches()) {
					price = TextUtils.parseDouble(priceMatcher.group(1));
					continue;
				}

				Matcher amountMatcher = AMOUNT_LINE.matcher(text);
				if (amountMatcher.matches()) {
					amount = TextUtils.parseLong(amountMatcher.group(1));
				}
			}
		}

		if (price <= 0.0D) {
			return java.util.Optional.empty();
		}

		return java.util.Optional.of(new BazaarOrder(productId, itemName, type, price, amount));
	}
}
