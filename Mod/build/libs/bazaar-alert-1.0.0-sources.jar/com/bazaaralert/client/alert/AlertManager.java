package com.bazaaralert.client.alert;

import com.bazaaralert.client.config.BazaarAlertConfig;
import com.bazaaralert.client.model.BazaarOrder;
import com.bazaaralert.client.model.OrderType;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public final class AlertManager {
	private final BazaarAlertConfig config;
	// Send repeated alerts while the condition remains true.
	// The caller (OutbidChecker) decides when to alert; we intentionally do not debounce here.
	private final Set<String> alertedKeys = new HashSet<>();

	public AlertManager(BazaarAlertConfig config) {
		this.config = config;
	}

	public void clearAlertState() {
		alertedKeys.clear();
	}

	public void markCompetitive(BazaarOrder order) {
		// No-op: repeated alerts are allowed.
	}

	public void notifyOutbid(BazaarOrder order, double competitorPrice) {

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null) {
			return;
		}

		String message = buildMessage(order, competitorPrice);
		if (config.chatAlerts) {
			client.field_1724.method_7353(class_2561.method_43470(message), false);
		}

		if (config.soundAlerts) {
			// Compatibility: LocalPlayer#playNotifySound signature/method name varies across MC versions.
			// Fallback to playing a sound via the world's sound manager when available.
			try {
				if (client.field_1687 != null) {
					client.field_1687.method_43128(
							null,
							client.field_1724.method_23317(),
							client.field_1724.method_23318(),
							client.field_1724.method_23321(),
							class_3417.field_14622.comp_349(),
							class_3419.field_15250,
							1.0F,
							0.5F
						);
				}
			} catch (Throwable ignored) {
				// no-op
			}
		}

	}

	private static String buildMessage(BazaarOrder order, double competitorPrice) {
		String action = order.type() == OrderType.BUY ? "overbid" : "undercut";
		return String.format(
			Locale.US,
			"§c[Bazaar Alert] §eYour %s §f%s §ewas %s! §7(You: §6%.1f§7, Top: §6%.1f§7)",
			order.type() == OrderType.BUY ? "buy order" : "sell offer",
			order.displayName(),
			action,
			order.pricePerUnit(),
			competitorPrice
		);
	}
}
