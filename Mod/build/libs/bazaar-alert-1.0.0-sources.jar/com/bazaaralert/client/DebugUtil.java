package com.bazaaralert.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.slf4j.Logger;

public final class DebugUtil {
	private DebugUtil() {}

	public static void sendChatOrLog(Logger logger, String message) {
		logger.warn("{}", message);
		try {
			class_310 mc = class_310.method_1551();
			if (mc.field_1724 != null) {
				mc.field_1724.method_7353(class_2561.method_43470(message), false);
			}
		} catch (Throwable ignored) {
			// no-op
		}
	}
}

