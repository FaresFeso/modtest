package com.bazaaralert.client.util;

import net.minecraft.class_266;
import net.minecraft.class_310;
import net.minecraft.class_8646;

public final class HypixelSkyblockUtils {
	private HypixelSkyblockUtils() {
	}

	public static boolean isOnHypixel() {
		class_310 client = class_310.method_1551();
		if (client.method_1558() == null) {
			return false;
		}

		String address = client.method_1558().field_3761.toLowerCase();
		return address.contains("hypixel");
	}

	public static boolean isLikelyInSkyblock() {
		class_310 client = class_310.method_1551();
		if (client.field_1687 == null) {
			return false;
		}

		class_266 objective = client.field_1687.method_8428().method_1189(class_8646.field_45157);
		if (objective == null) {
			return false;
		}

		String title = objective.method_1114().getString().toUpperCase();
		return title.contains("SKYBLOCK") || title.contains("SKIBLOCK");
	}
}
